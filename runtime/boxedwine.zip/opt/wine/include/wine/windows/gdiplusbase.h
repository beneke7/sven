/*
 * Copyright (C) 2024 Alistair Leslie-Hughes
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */
#ifndef _GDIPLUSBASE_H
#define _GDIPLUSBASE_H

#ifdef __cplusplus

class GdiplusBase
{
public:
    void (operator delete)(void *p)
    {
       DllExports::GdipFree(p);
    }

    void* (operator new)(size_t size)
    {
       return DllExports::GdipAlloc(size);
    }

    void (operator delete[])(void* p)
    {
       DllExports::GdipFree(p);
    }

    void* (operator new[])(size_t size)
    {
       return DllExports::GdipAlloc(size);
    }
};

#endif

#endif
